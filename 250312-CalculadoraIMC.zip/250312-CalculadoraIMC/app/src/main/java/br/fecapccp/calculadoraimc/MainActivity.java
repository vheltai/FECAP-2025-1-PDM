package br.fecapccp.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Metodo que Calcula o IMC:
    public void calculaImc(View view){
        // Instanciamento dos elementos:
        EditText campoAltura = findViewById(R.id.editTextAltura);
        EditText campoPeso = findViewById(R.id.editTextPeso);
        TextView resultado = findViewById(R.id.textResultado);

        // Variaveis para recuperar(get) e converter em Strings dos objetos:
        String altura = campoAltura.getText().toString();
        String peso = campoPeso.getText().toString();

        // Converter os dados peso e altura em Numerico e calcular o IMC:
        Double numAltura = Double.parseDouble(altura);
        Double numPeso = Double.parseDouble(peso);
        Double numImc = numPeso / (numAltura * numAltura);

        // Converter o numImc para String / Ajustar os dados e enviar:
        String imc = String.valueOf(numImc);

        // Formatar imc em duas casas decimais:
        DecimalFormat df = new DecimalFormat("##.##");
        imc = df.format(numImc);

        // Apresentar o resultado:
        resultado.setText(imc + " kg/m²");
    }

    // Metodo para Limpar as informações:
    public void limpar(View view){
        // Instanciamento dos elementos:
        EditText campoAltura = findViewById(R.id.editTextAltura);
        EditText campoPeso = findViewById(R.id.editTextPeso);
        TextView resultado = findViewById(R.id.textResultado);

        resultado.setText("-----");
        campoPeso.setText("");
        campoAltura.setText("");
    }
}