package br.fecapccp.textinput;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Metodo para Setar informações:
    public void enviar(View view){
        // Instanciamento dos Objetos do App:
        EditText campoNome = findViewById(R.id.editTextNome);
        EditText campoIdade = findViewById(R.id.editTextIdade);
        TextView resultado = findViewById(R.id.textResultado);

        // Criar variaveis para recuperar (get) o seu conteudo e converter em String:
        String nome = campoNome.getText().toString();
        String idade = campoIdade.getText().toString();

        // Apresentar o resultado:
        resultado.setText(nome + " tem " + idade + " anos.");

    }

    // Metodo para Resetar informações:
    public void limpar(View view){
        TextView resultado = findViewById(R.id.textResultado);
        EditText campoNome = findViewById(R.id.editTextNome);
        EditText campoIdade = findViewById(R.id.editTextIdade);
        resultado.setText("-----");
        campoNome.setText("");
        campoIdade.setText("");
    }
}