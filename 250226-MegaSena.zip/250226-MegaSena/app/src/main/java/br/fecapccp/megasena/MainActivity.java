package br.fecapccp.megasena;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void sortearNumeros(View view){
        // Instanciar os objetos TextViews como Array:
        TextView[] resultados = {
                findViewById(R.id.textNum1),
                findViewById(R.id.textNum2),
                findViewById(R.id.textNum3),
                findViewById(R.id.textNum4),
                findViewById(R.id.textNum5),
                findViewById(R.id.textNum6)
        };

        // Logica para sortear numeros de 1 a 60:
        Set<Integer> numerosSorteados = new HashSet<>();
        Random random = new Random();
        while(numerosSorteados.size() < 6){
            numerosSorteados.add(random.nextInt(60)+1);
        }

        // Converter para Lista afim de Ordenar:
        List<Integer> numerosOrdenados = new ArrayList<>(numerosSorteados);
        Collections.sort(numerosOrdenados);

        // Mostrar os resultados em ordem Crescente:
        for(int i=0; i<6; i++){
            resultados[i].setText(String.valueOf(numerosOrdenados.get(i)));
        }
    }

    public void limparNumeros(View view){
        TextView[] resultados = {
                findViewById(R.id.textNum1),
                findViewById(R.id.textNum2),
                findViewById(R.id.textNum3),
                findViewById(R.id.textNum4),
                findViewById(R.id.textNum5),
                findViewById(R.id.textNum6)
        };

        // Limpa todos os dados de textNum1 até textNum5
        for(int i=0; i<6; i++){
            resultados[i].setText("---");
        }
    }
}

