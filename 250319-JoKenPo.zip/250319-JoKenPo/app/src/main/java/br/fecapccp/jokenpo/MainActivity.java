package br.fecapccp.jokenpo;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Selecionando Pedra:
    public void selectPedra(View view){
        this.analiseJogo("pedra");
    }

    // Selecionando Papel:
    public void selectPapel(View view){
        this.analiseJogo("papel");
    }

    // Selecionando Tesoura:
    public void selectTesoura(View view){
        this.analiseJogo("tesoura");
    }

    // Analise das Opções Selecionadas / Jogadas:
    public void analiseJogo(String opcaoUser){
        // Instanciamento dos Objetos Manipulados:
        ImageView imgResultado = findViewById(R.id.imgResultado);
        TextView textResultado = findViewById(R.id.textResultado);
        String appUserWin   = getString(R.string.appUserWin);
        String appPCWin     = getString(R.string.appPCWin);
        String appEmpate    = getString(R.string.appEmpate);

        // Logica de Escolha do PC:
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoPC = opcoes[numero];

        // Logica Mudança de Figura (escolha do PC):
        switch (opcaoPC){
            case "pedra":
                imgResultado.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgResultado.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgResultado.setImageResource(R.drawable.tesoura);
                break;
        }

        // Logica do Jogo - Analisando Quem Ganhou e Quem Perdeu:
        if(
                (opcaoPC == "tesoura" && opcaoUser == "papel"    ||
                (opcaoPC == "papel"   && opcaoUser == "pedra")   ||
                (opcaoPC == "pedra"   && opcaoUser == "tesoura")  )
        ){
            // PC Ganhou e User Perdeu:
            textResultado.setText(appPCWin);
        }else if(
                (opcaoUser == "tesoura" && opcaoPC == "papel"    ||
                (opcaoUser == "papel"   && opcaoPC == "pedra")   ||
                (opcaoUser == "pedra"   && opcaoPC == "tesoura")  )
        ){
            // User Ganhou e PC Perdeu:
            textResultado.setText(appUserWin);
        }else{
            // Empatou
            textResultado.setText(appEmpate);
        }

    }
}